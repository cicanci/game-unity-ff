using UnityEngine;

namespace Zenject.Tests.Bindings.FromSubContainerPrefab
{
    public class Bar : MonoBehaviour
    {
    }
}

